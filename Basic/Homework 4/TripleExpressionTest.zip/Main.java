public class Main {
    public static void main(String[] args) {        
        double var = Double.parseDouble(args[0]);
        double ans = new Add(new Subtract(new Multiply(new Variable("x"), new Variable("y")), new Multiply(new Const(2), new Variable("z"))), new Const(1)).evaluate(var, var, var);
        System.out.println(ans);
    }
}
