public abstract class BinaryOperation implements Expression3 {
    Expression3 first, second;

    public BinaryOperation(Expression3 a, Expression3 b) {
        assert a != null;
        assert b != null;

        first = a;
        second = b;
    }
}
