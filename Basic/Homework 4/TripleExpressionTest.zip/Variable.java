public class Variable implements Expression3 {
    String var;

    public Variable(String s) {
        assert s != null;

        var = s;
    }

    public double evaluate(double x, double y, double z) {
        if (var == "x") {
            return x;
        } else if (var == "y") {
            return y;
        } else if (var == "z") {
            return z;
        } else {
            return 0.0;
        }
    }
}
