/**
 * @author Georgiy Korneev (kgeorgiy@kgeorgiy.info)
 * @version $$Id$$
 */
public interface Expression3 {
    double evaluate(double x, double y, double z);
}
